﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Hp : MonoBehaviour
{
	
	public float shieldTime;
	public float poisonTime;
	public int hp = 100;
	public int maxHp = 100;
	public int shield = 1;
	public bool poisoned = false;
	public Image hpBar;
	
	public GameObject SHIELD;
	public GameObject POISON;
	public GameObject CORPSE;
	
	public int dmg;
	
	
	public virtual void Update()
	{
		if(hp<=0)
			return;
		if(poisoned)
		{
			if(poisonTime<0)
			{
				updateHp(3,false);
				poisonTime=2;
			}
			poisonTime-=Time.deltaTime*1;
		}
		if(shieldTime>0)
		{
			shieldTime-=Time.deltaTime*1;
			if (shieldTime<=0)
			{
				SHIELD.SetActive(false);
				shield=1;
			}
		}
		
			Walk();
		
	}
	
	float timer=.5f;
	int mode=1;
	void Walk()
	{
		timer-=Time.deltaTime*1;
		if(timer<=0)
		{
			timer = 1;
			mode*=-1;
		}
		transform.Rotate(0,0,mode);
	}
	
	public void updateHp(int dmg, bool poison)
	{
		if(hp>0)
		{
			if(dmg>0)
				hp-=(dmg/shield);
			else
				hp-=dmg;
			
			if(hp<=0)
			{
				Corpse(true);
				hp=0;
			}
			else if(hp>maxHp)
			{
				hp=maxHp;
			}
			else if(poison&&shield==1)
			{
				if(Random.Range(1,4)==1)
				{
					poisoned=true;
					poisonTime=2;
					POISON.SetActive(true);
					PoisonSound();
				}
			}
			if(hpBar)
				hpBar.GetComponent<RectTransform>().sizeDelta = new Vector2(124*hp/maxHp,12);
		}
	}
	public virtual void PoisonSound(){}
	
	public void PopShield()
	{
		SHIELD.SetActive(true);
		shield=2;
		shieldTime=20;
	}
	
	public void CurePoison()
	{
		poisoned = false;
		POISON.SetActive(false);
	}
	
	public virtual void Corpse(bool mode)
	{
		if(mode)
		{
			SHIELD.SetActive(false);
			shield=1;
		}
		CurePoison();
		CORPSE.SetActive(mode);
	}

}
