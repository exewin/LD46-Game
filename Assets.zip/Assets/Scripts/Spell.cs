﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Spell : MonoBehaviour
{
	
	public AudioClip[] sounds;
	public AudioClip soundSelect;
	public AudioClip poiseSound;
	public AudioClip soundNotreadyyet;
	AudioSource audioSource;
	
	void Start()
    {
        audioSource = GetComponent<AudioSource>();
    }
	public string[] spellName;
	public float globalCooldown;
	public float[] cooldownTime;
	public float[] cooldownTimeMax;
	public Image[] cooldownImage;
	public Character[] chars;
	public int selectedSpell=0;
	public Text SelectedSpell;
	
	void Update()
	{
		if(globalCooldown>=0)
			globalCooldown-=Time.deltaTime*1;
		
		for(int i = 0; i<cooldownTime.Length; i++)
		{
			if(Input.GetKeyDown(""+(i+1)))
			{
				Select(i+1);
			}
			
			
			if(cooldownTime[i]>=0)
			{
				cooldownTime[i]-=Time.deltaTime*1;
			}
				if(cooldownTime[i]>globalCooldown)
					cooldownImage[i].GetComponent<RectTransform>().sizeDelta = new Vector2(64,64*cooldownTime[i]/cooldownTimeMax[i]);
				else
					cooldownImage[i].GetComponent<RectTransform>().sizeDelta = new Vector2(64,64*globalCooldown/1.5f);
		}
		
		
		
	}
	
	public void PlayPoison()
	{
		audioSource.PlayOneShot(poiseSound, 1);
	}
	
	
	public void Select(int s)
	{
		if(globalCooldown>0 || cooldownTime[s-1]>0)
		{
			audioSource.PlayOneShot(soundNotreadyyet, 1);
		}
		else
		{
			selectedSpell=s;
			SelectedSpell.text = "SELECTED SPELL: ("+s+") "+spellName[s-1];
			audioSource.PlayOneShot(soundSelect, 1);
		}
		
	}
	
	public void Cast(int character)
	{
		if(selectedSpell!=0)
		{
			
			if(selectedSpell==1) //single heal
			{
				audioSource.PlayOneShot(sounds[0], 1);
				chars[character].updateHp(-40,false);

			}
			else if(selectedSpell==2) //group heal
			{
				audioSource.PlayOneShot(sounds[1], 1);
				chars[character].updateHp(-15,false);
				for(int i = 0; i<chars.Length;i++)
				{
					chars[i].updateHp(-15,false);
				}

			}
			else if(selectedSpell==3) //resurrection
			{
				audioSource.PlayOneShot(sounds[2], 1);
				chars[character].hp=1;
				chars[character].updateHp(-150,false);
				chars[character].Corpse(false);


			}
			else if(selectedSpell==4) //pop shield
			{
				audioSource.PlayOneShot(sounds[3], 1);
				chars[character].PopShield();


			}
			else if(selectedSpell==5) //divine power
			{
				chars[character].PopShield();
				audioSource.PlayOneShot(sounds[4], 1);
				
				for(int i = 0; i<cooldownTime.Length; i++)
				{
					if(i==4)
						continue;
					cooldownTime[i]=0;
				}
				
				


			}
			else if(selectedSpell==6) //cure poison
			{
				audioSource.PlayOneShot(sounds[5], 1);
				chars[character].CurePoison();
				cooldownTime[5]=1;
			}
			cooldownTime[selectedSpell-1]=cooldownTimeMax[selectedSpell-1];
			globalCooldown = 1.5f;
		}
		
		selectedSpell = 0;
		SelectedSpell.text = "SELECTED SPELL: ";
		
	}
	


}
