﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Character : Hp
{
	
	public WaveC Controller;
	public Spell CastOn;
	public int id;
	
	public AudioClip atkSound;
	public float atkCooldown;
	public float atkCooldownMax = 2;
	public bool poise;
	public Enemy target;
	
	
	//0-none,1-pop shield,2-taunt
	public int specialSkill;
	public float specialSkillTimer=20;
	
	AudioSource audioSource;
	
	public override void Corpse(bool mode)
	{
		base.Corpse(mode);
		Controller.Alive();
	}
	
	public void OnMouseDown()
	{
		CastOn.Cast(id);
	}
	
		
	void Start()
    {
		atkCooldown = atkCooldownMax;
        audioSource = GetComponent<AudioSource>();
		SwitchTarget();
	}
	
	public override void Update()
	{
		base.Update();
		if(hp<=0)
			return;
		if(specialSkill==2)
		{
			specialSkillTimer-=Time.deltaTime*1;
			if(specialSkillTimer<=0)
			{
				specialSkillTimer=30;
				Controller.chars[Random.Range(0,Controller.chars.Length)].PopShield();
			}
		}
		if(Controller.gameOver)
		{
			return;
		}
		if(target)
			if(atkCooldown>0)
			{
				atkCooldown-=Time.deltaTime*1;
				if(atkCooldown<=0)
				{
					if(specialSkill==2)
					{
						target.target=this;
					}
					target.updateHp(dmg,poise);
					atkCooldown = Random.Range(atkCooldownMax/2,atkCooldownMax);
					audioSource.PlayOneShot(atkSound, 1);
					if(target)
						if(target.hp<=0)
						{
							SwitchTarget();
						}
				}
			}
	}
	
	public void SwitchTarget()
	{
		if(Controller.gameOver || Controller.enemies.Length<=0)
		{
			return;
		}
		
		target = Controller.enemies[Random.Range(0,Controller.enemies.Length)];
		
		if(target==null)
			SwitchTarget();
		else if(target.hp<=0)
			SwitchTarget();
		
	}
	
	public override void PoisonSound()
	{
		CastOn.PlayPoison();
	}
	


}
