﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : Hp
{
	public AudioClip atkSound;
	float atkCooldown;
	public float atkCooldownMax = 2;
	public bool poise;
	public bool atkAll;
	public Character target;
	public WaveC Controller;
	
	AudioSource audioSource;
	
	void Start()
    {
		atkCooldown = atkCooldownMax;
        audioSource = GetComponent<AudioSource>();
		SwitchTarget();
	}
	
	public override void Update()
	{
		base.Update();
		if(hp<=0)
			return;
		if(Controller.gameOver)
		{
			return;
		}
		if(atkCooldown>0)
		{
			atkCooldown-=Time.deltaTime*1;
			if(atkCooldown<=0)
			{
				if(target)
				{
					target.updateHp(dmg,poise);
					if(atkAll)
					{
						for(int i =0;i<Controller.chars.Length;i++)
						{
							Controller.chars[i].updateHp(dmg,poise);
						}
					}
				}
				
				atkCooldown = Random.Range(atkCooldownMax/2,atkCooldownMax);
				audioSource.PlayOneShot(atkSound, 1);
				if(target.hp<=0)
				{
					SwitchTarget();
				}
			}
		}
	}
	
	void SwitchTarget()
	{
		if(Controller.gameOver)
		{
			return;
		}
		if(Random.Range(1,4)==1)
		{
			target=Controller.chars[Random.Range(0,5)];
		}
		else
			target=GameObject.FindWithTag("Tank").GetComponent<Character>();
		
		if(target==null)
			SwitchTarget();
		else if(target.hp<=0)
			SwitchTarget();
		
	}
	
	public override void Corpse(bool mode)
	{
		base.Corpse(mode);
		Controller.AliveEnemies();
	}

}
