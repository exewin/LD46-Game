﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class WaveC : MonoBehaviour
{
	
	public Character[] chars;
	public Enemy[] enemies;
	GameObject[] enemiesG;
	public bool gameOver;
	public GameObject[] wave;
	public int curWave;
	
	public Text waveText;
	public Text waveTimerText;
	public float waveTimer;
	
	void Awake()
	{
		StartCoroutine(NewWave());
	}
	
	public void Alive()
	{
		if(chars[0].hp<=0)
			GameOver();
	}
	
	public void Update()
	{
		if(waveTimer>=0)
		{
			waveTimer-=Time.deltaTime*1;
			waveTimerText.text = " "+waveTimer.ToString("F2");
		}
	}
	
	public void AliveEnemies()
	{
		for(int i =0; i<enemies.Length;i++)
		{
			if(enemies[i].hp>0)
				return;
		}
		curWave++;
		if(curWave==15)
		{
			SceneManager.LoadScene("GameComplete", LoadSceneMode.Single);
		}
		StartCoroutine(NewWave());
	}
	
	void GameOver()
	{
		gameOver=true;
		SceneManager.LoadScene("GameOver", LoadSceneMode.Single);
	}
	
	void UnfreezeTimer()
	{
		waveTimer=7+curWave;
	}
	
	IEnumerator NewWave() //xd
	{
		for(int r =0; r<chars.Length;r++)
		{
			chars[r].target=null;
		}
		waveText.text = "WAVE: "+(curWave+1)+"/16";
		UnfreezeTimer();
		yield return new WaitForSeconds(7+curWave);
		
		for(int i =0; i<wave.Length;i++)
		{
			if(i==curWave)
				wave[i].SetActive(true);
			else
				wave[i].SetActive(false);
		}
		
		enemiesG = GameObject.FindGameObjectsWithTag("Enemy");
		enemies = new Enemy[enemiesG.Length];
		for(int j =0; j<enemiesG.Length;j++)
		{
			enemies[j] = enemiesG[j].GetComponent<Enemy>();
		}
		for(int s =0; s<chars.Length;s++)
		{
			chars[s].SwitchTarget();
		}
	}
	
}
